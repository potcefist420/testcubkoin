// Циферблат «Волчьи цитаты» для Xiaomi Smart Band 7 (Zepp OS 1.0, экран 192x490)
// Картинки лежат в assets/l66/images/. Их создаёт make_assets.py.
const IMG_DIR = 'images/';          // если в симуляторе нет картинок — поменяйте тут путь
const QUOTE_COUNT = 125;            // make_assets.py обновляет это число сам
const QUOTE_X = 0;
const QUOTE_Y = 350;

const img = (name) => IMG_DIR + name;
const seq = (prefix, n, from = 0) =>
  Array.from({ length: n }, (_, i) => img(prefix + String(i + from).padStart(2, '0') + '.png'));

let quoteWidget = null;
let shownQuote = -1;

// Номер цитаты зависит от даты и часа: каждый час новая,
// за 5 суток по кругу проходят все цитаты.
function pickQuote(time) {
  const monthDays = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  const dayOfYear = monthDays[time.month - 1] + time.day;
  const hourIndex = dayOfYear * 24 + time.hour;
  return (hourIndex * 37) % QUOTE_COUNT;
}

function refreshQuote(time) {
  const idx = pickQuote(time);
  if (idx === shownQuote) return;
  shownQuote = idx;
  if (quoteWidget) hmUI.deleteWidget(quoteWidget);
  quoteWidget = hmUI.createWidget(hmUI.widget.IMG, {
    x: QUOTE_X,
    y: QUOTE_Y,
    src: img('q' + String(idx).padStart(3, '0') + '.png'),
    show_level: hmUI.show_level.ONLY_NORMAL,
  });
}

WatchFace({
  build() {
    // чёрный фон
    hmUI.createWidget(hmUI.widget.FILL_RECT, {
      x: 0, y: 0, w: 192, h: 490, color: 0x000000,
      show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // маленький волк-квадратик сверху
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 60, y: 10, src: img('wolf.png'),
      show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // время ЧЧ:ММ
    hmUI.createWidget(hmUI.widget.IMG_TIME, {
      hour_zero: 1,
      hour_startX: 12,
      hour_startY: 96,
      hour_array: seq('t', 10),
      hour_space: 0,
      hour_align: hmUI.align.LEFT,
      minute_zero: 1,
      minute_startX: 104,
      minute_startY: 96,
      minute_array: seq('t', 10),
      minute_space: 0,
      minute_align: hmUI.align.LEFT,
      show_level: hmUI.show_level.ONLY_NORMAL,
    });
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 88, y: 96, src: img('colon.png'),
      show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // день недели по-русски (Пн … Вс)
    const week = seq('w', 7);
    hmUI.createWidget(hmUI.widget.IMG_WEEK, {
      x: 0, y: 170,
      week_en: week, week_tc: week, week_sc: week,
      show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // дата: «15 ноября»
    const days = seq('d', 31, 1);
    const months = seq('m', 12, 1);
    hmUI.createWidget(hmUI.widget.IMG_DATE, {
      day_startX: 0,
      day_startY: 208,
      day_is_character: true,
      day_en_array: days, day_sc_array: days, day_tc_array: days,
      month_startX: 86,
      month_startY: 208,
      month_is_character: true,
      month_en_array: months, month_sc_array: months, month_tc_array: months,
      show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // шаги
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 8, y: 258, src: img('lbl_steps.png'),
      show_level: hmUI.show_level.ONLY_NORMAL,
    });
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: 76, y: 258, w: 112, h: 28,
      type: hmUI.data_type.STEP,
      font_array: seq('s', 10),
      h_space: 0,
      align_h: hmUI.align.LEFT,
      show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // заряд батареи в процентах
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 8, y: 298, src: img('lbl_batt.png'),
      show_level: hmUI.show_level.ONLY_NORMAL,
    });
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: 76, y: 298, w: 112, h: 28,
      type: hmUI.data_type.BATTERY,
      font_array: seq('s', 10),
      h_space: 0,
      align_h: hmUI.align.LEFT,
      unit_en: img('percent.png'), unit_sc: img('percent.png'), unit_tc: img('percent.png'),
      show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // цитата, меняется раз в час
    const time = hmSensor.createSensor(hmSensor.id.TIME);
    refreshQuote(time);
    time.addEventListener(hmSensor.event.MINUTEEND, () => refreshQuote(time));
    hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
      resume_call: () => refreshQuote(time),
      pause_call: () => {},
    });
  },

  onInit() {},
  onDestroy() {
    quoteWidget = null;
    shownQuote = -1;
  },
});
