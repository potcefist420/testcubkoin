#!/usr/bin/env python3
"""Собирает готовый .bin для Xiaomi Smart Band 7 одной командой:  python build.py

Что делает:
  1) make_assets.py  — рисует картинки и цитаты;
  2) zeus build      — собирает проект Zepp OS (нужен Node.js и zeus-cli);
  3) достаёт из .zab -> .zpk -> device.zip и кладёт как .bin в dist/wolf_quotes/.
"""
import glob
import os
import shutil
import subprocess
import sys
import zipfile

NAME = "wolf_quotes"
DIST = "dist"


def run(cmd):
    print(">", cmd)
    if subprocess.call(cmd, shell=True) != 0:
        sys.exit(f"Команда не выполнилась: {cmd}")


def pack_bin():
    zabs = sorted(glob.glob(os.path.join(DIST, "*.zab")))
    if not zabs:
        sys.exit("В dist/ нет .zab — сборка zeus не удалась.")
    out = os.path.join(DIST, NAME)
    shutil.rmtree(out, ignore_errors=True)
    os.makedirs(out)
    tmp = os.path.join(DIST, "_tmp")
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    with zipfile.ZipFile(zabs[-1]) as zab:
        zab.extractall(tmp)
    zpks = sorted(glob.glob(os.path.join(tmp, "*.zpk")))
    if not zpks:
        sys.exit("Внутри .zab нет .zpk.")
    made = []
    for zpk in zpks:
        stem = os.path.splitext(os.path.basename(zpk))[0]
        with zipfile.ZipFile(zpk) as z:
            z.extract("device.zip", tmp)
        dst = os.path.join(out, stem + ".bin")
        shutil.copyfile(os.path.join(tmp, "device.zip"), dst)
        made.append(dst)
    main = next((m for m in made if os.path.basename(m).startswith("l66")), made[0])
    final = os.path.join(out, NAME + ".bin")
    shutil.copyfile(main, final)
    shutil.copyfile(os.path.join("assets", "l66", "images", "icon.png"), os.path.join(out, "icon.png"))
    shutil.rmtree(tmp, ignore_errors=True)
    print(f"\nГОТОВО: {final}\nИконка:  {os.path.join(out, 'icon.png')}")


def main():
    run(f'"{sys.executable}" make_assets.py ' + " ".join(sys.argv[1:]))
    if shutil.which("zeus") is None:
        sys.exit("Не найден zeus. Установите Node.js и выполните:  npm i @zeppos/zeus-cli -g")
    shutil.rmtree(DIST, ignore_errors=True)
    run("zeus build")
    pack_bin()


if __name__ == "__main__":
    main()
