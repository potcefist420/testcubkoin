#!/usr/bin/env python3
"""Генератор картинок для циферблата «Волчьи цитаты» (Xiaomi Smart Band 7, 192x490).

Запуск:
    python make_assets.py                 # волк-силуэт по умолчанию
    python make_assets.py --photo wolf.jpg   # свой снимок волка (будет обрезан в квадрат)

Нужен Pillow:  pip install pillow
Цитаты берутся из quotes.txt (одна цитата на строку, можно добавлять свои).
"""
import argparse
import os
import re
import sys
from PIL import Image, ImageDraw, ImageFont

W, H = 192, 490
OUT = os.path.join("assets", "l66", "images")

BRIGHT = (240, 240, 240)   # цифры времени
SOFT = (205, 205, 205)     # день недели, дата, цитата
DIM = (130, 130, 130)      # подписи «ШАГИ», «ЗАРЯД»

WOLF_SIZE = 72
QUOTE_W, QUOTE_H = 192, 110

FONT_DIRS = [
    "/usr/share/fonts/truetype/dejavu", "/usr/share/fonts/dejavu",
    "/usr/share/fonts/truetype/liberation", "C:/Windows/Fonts",
    "/Library/Fonts", "/System/Library/Fonts/Supplemental",
]
REG_NAMES = ["DejaVuSans.ttf", "arial.ttf", "Arial.ttf", "LiberationSans-Regular.ttf", "segoeui.ttf"]
BOLD_NAMES = ["DejaVuSans-Bold.ttf", "arialbd.ttf", "Arial Bold.ttf", "LiberationSans-Bold.ttf", "segoeuib.ttf"]


def find_font(names, override=None):
    if override and os.path.exists(override):
        return override
    for d in FONT_DIRS:
        for n in names:
            p = os.path.join(d, n)
            if os.path.exists(p):
                return p
    sys.exit("Не найден шрифт с кириллицей. Укажите путь: --font C:/Windows/Fonts/arial.ttf")


def F(path, size):
    return ImageFont.truetype(path, size)


def save(img, name):
    img.convert("RGB").save(os.path.join(OUT, name), optimize=True)


# ---------- волк ----------
def draw_wolf_silhouette(size):
    s = 8
    S = size * s
    img = Image.new("RGB", (S, S), (0, 0, 0))
    d = ImageDraw.Draw(img)

    def P(pts):
        return [(x * S / 100, y * S / 100) for x, y in pts]

    right = [(50, 30), (63, 28), (77, 4), (87, 36), (92, 52), (83, 58), (93, 70),
             (77, 75), (67, 91), (58, 98), (50, 98)]
    left = [(100 - x, y) for x, y in reversed(right)]
    head = right + left
    d.polygon(P(head), fill=(228, 228, 228))
    # внутренность ушей
    for sign in (1, -1):
        def X(x):
            return 50 + sign * (x - 50)
        d.polygon(P([(X(66), 29), (X(76), 13), (X(83), 36), (X(72), 34)]), fill=(70, 70, 70))
        # глаза
        d.polygon(P([(X(60), 55), (X(76), 49), (X(71), 60)]), fill=(0, 0, 0))
        d.polygon(P([(X(66), 55), (X(70), 53), (X(69), 57)]), fill=(255, 255, 255))
        # щёчный мех
        d.polygon(P([(X(88), 58), (X(80), 64), (X(84), 70)]), fill=(150, 150, 150))
    # нос и пасть
    d.polygon(P([(44, 88), (56, 88), (50, 96)]), fill=(0, 0, 0))
    d.line(P([(50, 96), (50, 100)]), fill=(0, 0, 0), width=int(S * 0.015))
    d.polygon(P([(50, 62), (54, 78), (50, 84), (46, 78)]), fill=(180, 180, 180))
    return img.resize((size, size), Image.LANCZOS)


def wolf_from_photo(path, size):
    im = Image.open(path).convert("L")
    w, h = im.size
    m = min(w, h)
    im = im.crop(((w - m) // 2, (h - m) // 2, (w - m) // 2 + m, (h - m) // 2 + m))
    im = im.resize((size, size), Image.LANCZOS)
    return Image.merge("RGB", (im, im, im))


# ---------- цифры ----------
def fit_digits(font_path, box_w, box_h):
    for size in range(120, 10, -1):
        f = F(font_path, size)
        ws, hs = [], []
        for ch in "0123456789":
            l, t, r, b = f.getbbox(ch, anchor="ls")
            ws.append(r - l)
            hs.append(b - t)
        if max(ws) <= box_w and max(hs) <= box_h:
            return f
    return F(font_path, 10)


def digit_images(prefix, font_path, w, h, color, pad_w, pad_h):
    f = fit_digits(font_path, w - pad_w, h - pad_h)
    l0, t0, r0, b0 = f.getbbox("0", anchor="ls")
    base = (h + (-t0)) // 2
    for i in range(10):
        img = Image.new("RGB", (w, h), (0, 0, 0))
        d = ImageDraw.Draw(img)
        l, t, r, b = f.getbbox(str(i), anchor="ls")
        d.text(((w - (r - l)) // 2 - l, base), str(i), font=f, fill=color, anchor="ls")
        save(img, f"{prefix}{i:02d}.png")


def colon_image(w, h):
    img = Image.new("RGB", (w, h), (0, 0, 0))
    d = ImageDraw.Draw(img)
    r = 4
    cx = w // 2
    for cy in (h * 0.34, h * 0.66):
        d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=BRIGHT)
    save(img, "colon.png")


def text_image(name, text, font, w, h, color, align="center", baseline=None, pad=0):
    img = Image.new("RGB", (w, h), (0, 0, 0))
    d = ImageDraw.Draw(img)
    l, t, r, b = font.getbbox(text, anchor="ls")
    tw = r - l
    if align == "center":
        x = (w - tw) // 2 - l
    elif align == "right":
        x = w - pad - tw - l
    else:
        x = pad - l
    if baseline is None:
        baseline = (h + (-t) + 0) // 2
    d.text((x, baseline), text, font=font, fill=color, anchor="ls")
    save(img, name)


def fit_font(font_path, texts, max_w, max_size, min_size=10):
    for size in range(max_size, min_size, -1):
        f = F(font_path, size)
        if all((f.getbbox(t, anchor="ls")[2] - f.getbbox(t, anchor="ls")[0]) <= max_w for t in texts):
            return f
    return F(font_path, min_size)


# ---------- цитаты ----------
def wrap(text, font, max_w):
    words, lines, cur = text.split(), [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if font.getlength(trial) <= max_w or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def quote_image(idx, text, font_path):
    for size in range(22, 11, -1):
        f = F(font_path, size)
        lh = int(size * 1.22)
        lines = wrap(text, f, QUOTE_W - 8)
        if len(lines) * lh <= QUOTE_H - 4 and all(f.getlength(x) <= QUOTE_W - 4 for x in lines):
            break
    else:
        print(f"  ! цитата №{idx} не влезла: {text}")
    img = Image.new("RGB", (QUOTE_W, QUOTE_H), (0, 0, 0))
    d = ImageDraw.Draw(img)
    total = len(lines) * lh
    y = (QUOTE_H - total) // 2
    for ln in lines:
        d.text((QUOTE_W // 2, y), ln, font=f, fill=SOFT, anchor="mt")
        y += lh
    save(img, f"q{idx:03d}.png")
    return size, len(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--photo", help="свой снимок волка (jpg/png)")
    ap.add_argument("--font", help="шрифт с кириллицей (обычный)")
    ap.add_argument("--font-bold", help="шрифт с кириллицей (жирный)")
    a = ap.parse_args()

    os.makedirs(OUT, exist_ok=True)
    reg = find_font(REG_NAMES, a.font)
    bold = find_font(BOLD_NAMES, a.font_bold)

    # волк + иконка приложения
    wolf = wolf_from_photo(a.photo, WOLF_SIZE) if a.photo else draw_wolf_silhouette(WOLF_SIZE)
    save(wolf, "wolf.png")
    icon = wolf_from_photo(a.photo, 192) if a.photo else draw_wolf_silhouette(192)
    save(icon, "icon.png")

    # время
    digit_images("t", bold, 38, 64, BRIGHT, 2, 4)
    colon_image(16, 64)

    # шаги / батарея
    digit_images("s", bold, 18, 28, BRIGHT, 1, 4)
    f_small = fit_font(bold, ["%"], 22, 24)
    text_image("percent.png", "%", f_small, 22, 28, BRIGHT, align="left")
    f_lbl = fit_font(bold, ["ШАГИ", "ЗАРЯД"], 62, 20)
    text_image("lbl_steps.png", "ШАГИ", f_lbl, 64, 28, DIM, align="left")
    text_image("lbl_batt.png", "ЗАРЯД", f_lbl, 64, 28, DIM, align="left")

    # день недели (Пн … Вс)
    week = ["ПОНЕДЕЛЬНИК", "ВТОРНИК", "СРЕДА", "ЧЕТВЕРГ", "ПЯТНИЦА", "СУББОТА", "ВОСКРЕСЕНЬЕ"]
    f_week = fit_font(bold, week, 182, 28)
    for i, name in enumerate(week):
        text_image(f"w{i:02d}.png", name, f_week, 192, 34, SOFT, align="center", baseline=25)

    # дата: число справа в левой половине, месяц слева в правой
    months = ["января", "февраля", "марта", "апреля", "мая", "июня",
              "июля", "августа", "сентября", "октября", "ноября", "декабря"]
    f_date = fit_font(bold, months, 104, 28)
    for i, name in enumerate(months, 1):
        text_image(f"m{i:02d}.png", name, f_date, 106, 34, SOFT, align="left", baseline=25)
    for n in range(1, 32):
        text_image(f"d{n:02d}.png", str(n), f_date, 76, 34, BRIGHT, align="right", baseline=25)

    # цитаты
    with open("quotes.txt", encoding="utf-8") as fh:
        quotes = [ln.strip() for ln in fh if ln.strip()]
    # удалить старые картинки цитат, если их стало меньше
    for fn in os.listdir(OUT):
        if re.fullmatch(r"q\d{3}\.png", fn):
            os.remove(os.path.join(OUT, fn))
    sizes = []
    for i, q in enumerate(quotes):
        sizes.append(quote_image(i, q, reg))
    print(f"Цитат: {len(quotes)}, размер шрифта {min(s for s, _ in sizes)}–{max(s for s, _ in sizes)} px")

    # прописать количество цитат в index.js
    p = os.path.join("watchface", "index.js")
    src = open(p, encoding="utf-8").read()
    src = re.sub(r"const QUOTE_COUNT = \d+;", f"const QUOTE_COUNT = {len(quotes)};", src)
    open(p, "w", encoding="utf-8").write(src)

    make_preview(quotes)
    total = sum(os.path.getsize(os.path.join(OUT, f)) for f in os.listdir(OUT))
    print(f"Готово. Картинок: {len(os.listdir(OUT))}, всего {total // 1024} КБ")


def make_preview(quotes):
    """Макет циферблата (10:09, воскресенье 15 ноября) для проверки раскладки."""
    def L(n):
        return Image.open(os.path.join(OUT, n))
    img = Image.new("RGB", (W, H), (0, 0, 0))
    img.paste(L("wolf.png"), (60, 10))
    x = 12
    for ch in "10":
        img.paste(L(f"t0{ch}.png"), (x, 96)); x += 38
    img.paste(L("colon.png"), (88, 96))
    x = 104
    for ch in "09":
        img.paste(L(f"t0{ch}.png"), (x, 96)); x += 38
    img.paste(L("w06.png"), (0, 170))
    img.paste(L("d15.png"), (0, 208))
    img.paste(L("m11.png"), (86, 208))
    img.paste(L("lbl_steps.png"), (8, 258))
    x = 76
    for ch in "8421":
        img.paste(L(f"s0{ch}.png"), (x, 258)); x += 18
    img.paste(L("lbl_batt.png"), (8, 298))
    x = 76
    for ch in "87":
        img.paste(L(f"s0{ch}.png"), (x, 298)); x += 18
    img.paste(L("percent.png"), (x, 298))
    img.paste(L("q000.png"), (0, 350))
    img.resize((W * 2, H * 2), Image.NEAREST).save("preview.png")


if __name__ == "__main__":
    main()
